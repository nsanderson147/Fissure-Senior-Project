﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//Sends the player to the next level if they touch this object
public class PlaceExit : MonoBehaviour {

	private void OnTriggerEnter(Collider other){
		SceneManager.LoadScene (SceneManager.GetActiveScene().buildIndex + 1);

	}
}
