﻿
using UnityEngine;

[RequireComponent(typeof(Player_Motor))]

//Get player input and translate it into character movement with the player_motor class
public class Player_Controller : MonoBehaviour {

	//Player speed
	[SerializeField]
	private float speed = 5f;
	
	//Mouse sensitivity
	[SerializeField]
	private float looksens = 3f;

	private Player_Motor motor;

	void Start () {
		motor = GetComponent<Player_Motor>();
		Screen.lockCursor = true;
	}

	void Update () {
		//Get input
		float _xMov = Input.GetAxisRaw("Horizontal");
		float _zMov = Input.GetAxisRaw("Vertical");
		bool _jump = Input.GetKeyDown ("space");

		//Translate input into vectors
		Vector3 _movHorizontal = transform.right * _xMov;
		Vector3 _movVertical = transform.forward * _zMov;

		Vector3 _velocity = (_movHorizontal + _movVertical).normalized * speed;

		motor.Move(_velocity);

		//Calculate rotation
		float _yRot = Input.GetAxisRaw("Mouse X");

		Vector3 _rotation = new Vector3 (0f, _yRot, 0f) * looksens;

		//Apply rotation
		motor.Rotate(_rotation);

		//Calculate camera rotation
		float _xRot = Input.GetAxisRaw("Mouse Y");
		_xRot = Mathf.Clamp(_xRot, -30f, 60f); 
		Vector3 _cameraRotation = new Vector3 (_xRot, 0f, 0f) * looksens;

		//Apply camera rotation
		motor.RotateCamera(_cameraRotation);

		//Send jump input
		motor.TestJump(_jump);
	}
}
