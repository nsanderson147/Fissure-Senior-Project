﻿using UnityEngine; 
using System.Collections;
using UnityEngine.SceneManagement;

//Instantiate a bullet with a given velocity away from the camera when the mouse is left clicked
public class Gunfire : MonoBehaviour 
{
	public float bulletSpeed = 10f;
	public Rigidbody bullet;


	void Fire()
	{
		Rigidbody bulletClone = (Rigidbody) Instantiate(bullet, transform.position, transform.rotation);
		bulletClone.velocity = -transform.up * bulletSpeed;
	}

	void Update () 
	{
		if (Input.GetButtonDown("Fire1"))
			Fire();
	}
}