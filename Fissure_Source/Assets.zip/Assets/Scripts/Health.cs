﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//Keep track of player's health
public class Health : MonoBehaviour {
	int hits = 5;
	
	//Return to title if health drops to 0, exit game if esc key is pressed
	void Update () {
		if (hits < 1) {
			SceneManager.LoadScene (0);
		}

		if (Input.GetKey ("escape")) {
			Application.Quit();
		}
	}

	//Decrement health if player touches an enemy
	void OnCollisionEnter(Collision hit){
		if (hit.gameObject.name == "EnemyTarget")
			hits--;
	}


}
