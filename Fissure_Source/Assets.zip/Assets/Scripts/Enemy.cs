﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Basic enemy object that decrements its HP once it is hit by an object. If its hp is zero it is destroyed
public class Enemy : MonoBehaviour {
	[SerializeField]
	int hp = 5;

	void Update () {

		if (hp < 0) {
			Destroy (this.gameObject);
		}
	}

	void OnCollisionEnter(Collision collide){
		hp--;
	}

}
