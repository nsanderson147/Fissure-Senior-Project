﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//Moves to the first game scene once a button is pressed
public class Advance : MonoBehaviour
{

    void Update()
    {
        if (Input.anyKeyDown){
			SceneManager.LoadScene (1);
		}
    }
}
