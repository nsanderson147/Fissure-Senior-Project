﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Code for the player's bullet that destroys itself once a timer runs out or it hits a target object
public class Bullet : MonoBehaviour {
	//Time before the bullet despawns
	private int BulletTimer;
	[SerializeField]
	
	//Object that destroys the bullet (eg. enemies)
	GameObject Target;
	[SerializeField]
	
	void Start(){
		BulletTimer = 50;
	}
	void Update(){
		if (BulletTimer > 0)
			BulletTimer--;
		else Destroy (gameObject);
	}
	void OnCollisionEnter(Collision collision){
		if(collision.gameObject == Target) Destroy (gameObject);
	}
}
