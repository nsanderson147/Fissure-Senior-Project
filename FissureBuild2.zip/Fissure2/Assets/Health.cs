﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour {
	int hits = 5;
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		if (hits < 1) {
			SceneManager.LoadScene (1);
		}

		if (Input.GetKey ("escape")) {
			Application.Quit();
		}
	}

	void OnCollisionEnter(Collision hit){
		if (hit.gameObject.name == "EnemyTarget")
			hits--;
	}

	void OnGUI(){
		GUI.color = Color.red;
		GUI.Label(new Rect (20,20,200,20), "Health = " + hits);
	}
}
