﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {
	[SerializeField]
	int hp = 5;

	[SerializeField]
	GameObject damager;

	[SerializeField]
	Rigidbody projectile;


	float speed = 3.0f;
	GameObject target = null;
	Vector3 lastPos = Vector3.zero;
	Quaternion lookAtRot;

	int timer = 30;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		/*if (target) {
			if (lastPos != target.transform.position) {
				lastPos = target.transform.position;
				lookAtRot = Quaternion.LookRotation (lastPos - transform.position);
			}
			if (transform.rotation != lookAtRot) {
				transform.rotation = Quaternion.RotateTowards (transform.rotation, lookAtRot, speed * Time.deltaTime);
			}
		}

		timer--;
		if (timer < 0) {
			Rigidbody bullet = (Rigidbody)Instantiate(projectile, transform.position + transform.forward, transform.rotation);
			bullet.AddForce(transform.forward*20.0f, ForceMode.Impulse);
			timer = 30;
		}*/

		if (hp < 0) {
			Destroy (this.gameObject);
		}
	}

	void OnCollisionEnter(Collision collide){
		hp--;
	}

}
