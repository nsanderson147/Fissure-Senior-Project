﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent (typeof(MeshFilter), typeof(MeshRenderer))]
public class CeilingGrid : MonoBehaviour {

	public int xSize, ySize;

	private Vector3[] vertices;
	private Mesh mesh;

	public static float StartHeight = 0f;

	float currentHeight = StartHeight;

	private void Awake () {
		Generate ();
	}

	private void Generate (){

		GetComponent<MeshFilter>().mesh = mesh = new Mesh();
		mesh.name = "Procedural Grid";

		vertices = new Vector3[(xSize + 1) * (ySize + 1)];
		Vector2[] uv = new Vector2[vertices.Length];
		for (int i = 0, y = 0; y <= ySize; y++) {
			for (int x = 0; x <= xSize; x++, i++) {
				if (i > xSize + 1) currentHeight = (vertices [i - xSize].y + currentHeight) / 2;
				currentHeight += Random.Range (-0.2f, 0.2f);
				if (currentHeight > (10.0f + StartHeight))
					currentHeight = (10.0f + StartHeight);
				if (currentHeight < (-10.0f+StartHeight))
					currentHeight = (-10.0f+StartHeight);
				vertices[i] = new Vector3(x, currentHeight, y);
				uv [i] = new Vector2 ((float)x / xSize, (float)y / ySize);
			}
		}

		mesh.vertices = vertices;
		mesh.uv = uv;

		int[] triangles = new int[xSize*ySize*6];
		for (int ti = 0, vi = 0, y = 0; y < ySize; y++, vi++) {
			for (int x = 0; x < xSize; x++, ti += 6, vi++) {
				triangles [ti] = vi;
				triangles [ti + 3] = triangles [ti + 2] = vi + 1;
				triangles [ti + 4] = triangles [ti + 1] = vi + xSize + 1;
				triangles [ti + 5] = vi + xSize + 2;
			}
		}
		mesh.triangles = triangles;

		mesh.RecalculateNormals();

		MeshCollider meshc = gameObject.AddComponent(typeof(MeshCollider)) as MeshCollider;

		meshc.sharedMesh = mesh;
	}

}
