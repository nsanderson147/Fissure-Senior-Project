﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlacePlayer : MonoBehaviour {
	Vector3 testpoint;
	[SerializeField]
	Collider collide;

	void Start(){
		StartCoroutine (place ());
	}
	// Use this for initialization
	IEnumerator place () {
		yield return new WaitForSeconds (1);
		int x, z;
		for(z = 5; z < 55; z+= 5){
			for (x = 5; x < 55; x+= 5) {
				testpoint.Set(x, 5, z);
				if(!collide.bounds.Contains(testpoint)){
					x = 56;
					z = 56;
				}
			}
		}
		transform.position = testpoint;
	}
}
